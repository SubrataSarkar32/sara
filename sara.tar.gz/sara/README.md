# sara
A virtual assistant made in python. Currently it just searches for you when say a statement starting with 'search'/'search for' and writes to .txt file when you say a statement starting with'write'.

Requires:
->speech_recognition
->pyttsx
->pyaudio
->PIL

other requirements for the above mentioned packages.
